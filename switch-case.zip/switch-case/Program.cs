﻿//switch-case
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace switch_case
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set console color red=1");
            Console.WriteLine("set console color yellow=2");
            Console.WriteLine("set console color green=3");
            Console.Write("enter the color code:");
            int n = Convert.ToInt32(Console.ReadLine());
            switch(n)
            {
                case 1: 
                    Console.BackgroundColor = ConsoleColor.Red;
                   Console.Clear();
                    break;
                case 2: 
                    Console.BackgroundColor = ConsoleColor.DarkYellow;
                    Console.Clear();
                    break;
                case 3: 
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;
                default:
                    Console.Write("please enter a right color code");
                    break;
            }
            Console.Read();
        }
    }
}