﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/* 
 * 1
 * 2 3
 * 6 18 108 */

namespace pyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            // using Do..while Loop
            Console.Write("Enter any nubmer: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, old = 2, New = 4, K = 1;
            do
            {
                int j = 1;
                do
                {
                    if (K <= 4)
                    {
                        Console.Write(K + " ");
                    }
                    else
                    {
                        K = old * New;
                        if (K > n)
                        {
                            break;
                        }
                        Console.Write(K + " ");
                        old = New;
                        New = K;
                    }
                    K++;
                    j++;
                } while (j <= i);
                i++;
                if (K > n)
                {
                    break;
                }
                Console.WriteLine();
            } while (i <= n);
            Console.Read();

          /*  // using for Loop
            int a = 2, b = 3, c = 1;
            Console.Write("\n\nEnter any number[For] : ");
            int num = Convert.ToInt32(Console.ReadLine());
          
            for (int i = 1; i <= num; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    if (c <= 3)
                    {
                        Console.Write(c + " ");
                    }
                    else
                    {
                        c = a * b;
                        if (c > num)
                        {
                            break;
                        }
                        Console.Write(c + " ");
                        a = b;
                        b = c;
                    }
                    c++;
                }
                if (c > num)
                {
                    break;
                }
                Console.WriteLine();
            }
            Console.Read();
            // using for While
            Console.Write("\n\nEnter any nubmer[while] : ");
            int number = Convert.ToInt32(Console.ReadLine());
            int present = 1, past = 2, future = 3, temp = 1;
            while (present <= number)
            {
                int temp_1 = 1;
                while (temp_1 <= present) 
                {
                    if (temp <= 3)
                    {
                        Console.Write(temp + " ");
                    }
                    else
                    {
                        temp = past * future;
                        if (temp > number)
                        {
                            break;
                        }
                        Console.Write(temp + " ");
                        past = future;
                        future = temp;
                    }
                    temp++;
                    temp_1++;
                } while (temp_1 <= present);
                present++;
                if (temp > number)
                {
                    break;
                }
                Console.WriteLine();
            } */

            Console.Read();
        }
    }
}

